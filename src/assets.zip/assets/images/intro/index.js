import icIntroAppleBtn from './ic_intro_apple_btn.svg';
import icIntroGoogleBtn from './ic_intro_google_btn.svg';
import icIntroKakaoBtn from './ic_intro_kakao_btn.svg';
import icIntroNaverBtn from './ic_intro_naver_btn.svg';

import imgIntroArtist1 from './img_intro_artist1.svg';
import imgIntroArtist2 from './img_intro_artist1.svg';
import imgIntroArtist3 from './img_intro_artist1.svg';
import imgIntroArtist4 from './img_intro_artist1.svg';
import imgIntroRecruiter1 from './img_intro_recruiter1.svg';
import imgIntroRecruiter2 from './img_intro_recruiter2.svg';
import imgIntroRecruiter3 from './img_intro_recruiter3.svg';

export {
  icIntroAppleBtn,
  icIntroGoogleBtn,
  icIntroKakaoBtn,
  icIntroNaverBtn,
  imgIntroArtist1,
  imgIntroArtist2,
  imgIntroArtist3,
  imgIntroArtist4,
  imgIntroRecruiter1,
  imgIntroRecruiter2,
  imgIntroRecruiter3,
};
