import bgSignUnderline from './bg_sign_underline.svg';
import imgSignCongratsChar from './img_sign_congrats_char.svg';

export {bgSignUnderline, imgSignCongratsChar};
