import bgStartArtkulogo from './bg_start_artkulogo.svg';
import bgStartUnderline from './bg_start_underline.svg';
import logoStartArtku from './logo_start_artku.svg';

export {bgStartArtkulogo, bgStartUnderline, logoStartArtku};
